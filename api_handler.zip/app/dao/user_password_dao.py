
class UserPasswordDao:
    def __init__(self):
        pass

    def get_user_password(self, user_pass_model):
        print(user_pass_model.password)
        return True