
class UserNameDetailsDao:
    def __init__(self):
        pass

    def if_user_name_exist(self, user_model):
        print(user_model.user_name)
        return True