

class APIEndpoints:
    api_endpoints = {
        'login/POST': {"File": "login", "Function": "user_login"},
        'login/PUT': {"File": "opticloud_product", "Function": "retry_opticloud_product"},
    }

