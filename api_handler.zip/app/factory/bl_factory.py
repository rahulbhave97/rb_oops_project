

class BLFactory:
    def __init__(self, factory):
        self._factory = factory

    def login_bl(self):
        from app.BL.login import LoginBL
        return LoginBL(self._factory)
