
class DaoFactory:
    def __init__(self):
        pass

    def user_name_details_dao(self):
        from app.dao.user_name_details_dao import UserNameDetailsDao
        return UserNameDetailsDao()

    def user_password_dao(self):
        from app.dao.user_password_dao import UserPasswordDao
        return UserPasswordDao()
