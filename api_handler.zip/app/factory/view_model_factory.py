
class ViewModelFactory:
    def __init__(self, factory):
        self._factory = factory

    def get_login_model(self, event):
        from app.ViewModel.login import LoginViewModel
        return LoginViewModel(event, self._factory)
