

class DataModelFactory:
    def __init__(self):
        pass
