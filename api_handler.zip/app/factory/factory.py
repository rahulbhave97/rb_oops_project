

class Factory:
    def __init__(self):
        self._dao = None
        self._bl = None
        self._view_model = None
        self._data_model = None

    def dao_factory(self):
        if not self._dao:
            from app.factory.dao_factory import DaoFactory
            self._dao = DaoFactory()
        return self._dao

    def bl_factory(self):
        if not self._bl:
            from app.factory.bl_factory import BLFactory
            self._bl = BLFactory(self)
        return self._bl

    def view_model_factory(self):
        if not self._view_model:
            from app.factory.view_model_factory import ViewModelFactory
            self._view_model = ViewModelFactory(self)
        return self._view_model

    def data_model_factory(self):
        if not self._data_model:
            from app.factory.data_model_factory import DataModelFactory
            self._data_model = DataModelFactory()
        return self._data_model
