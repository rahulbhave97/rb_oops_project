from app.base_class.endpoint_base import EndpointBase


# class LoginEndpoint(EndpointBase):
#     Name = 'login'

def user_login(event, factory):
    login_model = factory.view_model_factory().get_login_model(event)
    response = factory.bl_factory().login_bl().validate_user_login(login_model)
    return response
