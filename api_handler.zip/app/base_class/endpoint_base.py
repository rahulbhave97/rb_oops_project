
class EndpointBase:
    def __init__(self):
        pass
