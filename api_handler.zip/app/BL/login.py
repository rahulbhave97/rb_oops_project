from app.base_class.bl_base import BLBase


class LoginBL(BLBase):
    def __init__(self, factory):
        super().__init__()
        self._factory = factory
        self._dao = self._factory.dao_factory()

    def validate_user_login(self, login_model):
        if self._dao.user_name_details_dao().if_user_name_exist(login_model.user_name):
            result = self._dao.user_passord_dao().get_user_password(login_model.get_user_pass_model())
            if result:
                return True
        else:
            login_model.return_signup = True

    def create_signup(self):
        pass
