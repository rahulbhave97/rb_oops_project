from app.base_class.view_model_base import ViewModelBase


class LoginViewModel(ViewModelBase):
    def __init__(self, event, factory):
        super().__init__(event)
        self._event = event
        self._factory = factory
        self._data_model_factory = self._factory.data_model_factory()
        self._populate()

    @staticmethod
    def get_model(factory):
        return LoginViewModel(dict(), factory)

    def _populate(self):
        self.user_name = self.body_json.get('user_name')
        self.password = self.body_json.get('password')
        self.return_signup = False

    def get_user_data_model(self):
        return self._data_model_factory.user_data_model()

    def get_user_pass_model(self):
        return self._data_model_factory.get_user_pass_model()
